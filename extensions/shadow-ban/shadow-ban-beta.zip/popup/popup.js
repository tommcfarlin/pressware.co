let successTimer = null;

function showSuccessMessage(message) {
  const el = document.getElementById('success-message');
  el.textContent = message;
  el.classList.remove('hidden');
  if (successTimer) clearTimeout(successTimer);
  successTimer = setTimeout(() => {
    el.classList.add('hidden');
  }, 3000);
}

async function refreshActiveGmailTab() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab) {
      await chrome.tabs.sendMessage(tab.id, { type: 'REFRESH_INBOX' });
    }
  } catch (_err) {
    // Active tab isn't Gmail or content script not loaded — ignore
  }
}

function updateBulkButton() {
  const checked = document.querySelectorAll('.sender-checkbox:checked');
  const bulkBtn = document.getElementById('bulk-unban-btn');
  if (checked.length > 0) {
    bulkBtn.classList.remove('hidden');
    bulkBtn.textContent = `Unban Selected (${checked.length})`;
  } else {
    bulkBtn.classList.add('hidden');
  }
}

async function loadBannedSenders() {
  const { senders } = await chrome.runtime.sendMessage({ type: 'GET_BANNED_LIST' });
  const container = document.getElementById('banned-senders');
  const countEl = document.getElementById('banned-count');
  const emptyEl = document.getElementById('empty-state');
  const bulkBtn = document.getElementById('bulk-unban-btn');

  countEl.textContent = `(${senders.length})`;
  container.innerHTML = '';
  bulkBtn.classList.add('hidden');

  if (senders.length === 0) {
    emptyEl.classList.remove('hidden');
    return;
  }

  emptyEl.classList.add('hidden');

  // Select All row
  if (senders.length > 1) {
    const selectAllRow = document.createElement('div');
    selectAllRow.className = 'sender-row select-all-row';

    const label = document.createElement('label');
    label.className = 'checkbox-label';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.id = 'select-all';
    cb.className = 'sender-checkbox-all';

    const text = document.createElement('span');
    text.className = 'sender-email';
    text.textContent = 'Select All';

    label.appendChild(cb);
    label.appendChild(text);
    selectAllRow.appendChild(label);
    container.appendChild(selectAllRow);
  }

  for (const sender of senders) {
    const row = document.createElement('div');
    row.className = 'sender-row';

    const label = document.createElement('label');
    label.className = 'checkbox-label';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'sender-checkbox';
    cb.dataset.sender = sender;

    const emailSpan = document.createElement('span');
    emailSpan.className = 'sender-email';
    emailSpan.textContent = sender;

    label.appendChild(cb);
    label.appendChild(emailSpan);

    const btn = document.createElement('button');
    btn.className = 'unban-btn';
    btn.dataset.sender = sender;
    btn.textContent = 'Unban';

    row.appendChild(label);
    row.appendChild(btn);
    container.appendChild(row);
  }
}

async function loadFilterStatus() {
  const status = await chrome.runtime.sendMessage({ type: 'GET_FILTER_STATUS' });
  const container = document.getElementById('filters');
  container.innerHTML = '';

  if (!status || status.length === 0) return;

  for (const filter of status) {
    const row = document.createElement('div');
    row.className = 'filter-row';
    const pct = Math.round((filter.charCount / filter.charLimit) * 100);

    const label = document.createElement('span');
    label.textContent = `Filter ${filter.index + 1}: ${filter.addressCount} addresses`;

    const bar = document.createElement('div');
    bar.className = 'progress-bar';
    const fill = document.createElement('div');
    fill.className = 'progress-fill';
    fill.style.width = `${pct}%`;
    bar.appendChild(fill);

    const pctLabel = document.createElement('span');
    pctLabel.className = 'progress-label';
    pctLabel.textContent = `${filter.charCount} / ${filter.charLimit}`;

    row.appendChild(label);
    row.appendChild(bar);
    row.appendChild(pctLabel);
    container.appendChild(row);
  }
}

// Individual unban
document.getElementById('banned-senders').addEventListener('click', async (e) => {
  if (!e.target.classList.contains('unban-btn')) return;
  const sender = e.target.dataset.sender;
  const btn = e.target;
  btn.disabled = true;
  btn.classList.add('btn-loading');

  try {
    const result = await chrome.runtime.sendMessage({
      type: 'UNBAN_SENDER',
      payload: { address: sender },
    });
    const count = result?.restoredCount || 0;
    const msg = count > 0
      ? `Unbanned ${sender} — ${count} message${count === 1 ? '' : 's'} restored`
      : `Unbanned ${sender}`;
    showSuccessMessage(msg);
    await loadBannedSenders();
    await loadFilterStatus();
    await refreshActiveGmailTab();
  } catch (err) {
    btn.disabled = false;
    btn.classList.remove('btn-loading');
    alert(`Failed to unban ${sender}: ${err.message}`);
  }
});

// Checkbox changes — update bulk button visibility
document.getElementById('banned-senders').addEventListener('change', (e) => {
  // Select All toggle
  if (e.target.classList.contains('sender-checkbox-all')) {
    const checkboxes = document.querySelectorAll('.sender-checkbox');
    for (const cb of checkboxes) {
      cb.checked = e.target.checked;
    }
  }

  // Uncheck "Select All" if any individual is unchecked
  if (e.target.classList.contains('sender-checkbox') && !e.target.checked) {
    const selectAll = document.getElementById('select-all');
    if (selectAll) selectAll.checked = false;
  }

  updateBulkButton();
});

// Bulk unban
document.getElementById('bulk-unban-btn').addEventListener('click', async (e) => {
  const checked = document.querySelectorAll('.sender-checkbox:checked');
  if (checked.length === 0) return;

  const addresses = [...checked].map((cb) => cb.dataset.sender);
  const btn = e.target;
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.classList.add('btn-loading');

  try {
    const result = await chrome.runtime.sendMessage({
      type: 'BULK_UNBAN',
      payload: { addresses },
    });
    const unbanned = result?.unbannedCount || addresses.length;
    const restored = result?.restoredCount || 0;
    const parts = [`Unbanned ${unbanned} sender${unbanned === 1 ? '' : 's'}`];
    if (restored > 0) {
      parts.push(`${restored} message${restored === 1 ? '' : 's'} restored`);
    }
    showSuccessMessage(parts.join(' — '));
    await loadBannedSenders();
    await loadFilterStatus();
    await refreshActiveGmailTab();
  } catch (err) {
    btn.disabled = false;
    btn.classList.remove('btn-loading');
    btn.textContent = originalText;
    alert(`Failed to unban: ${err.message}`);
  }
});

loadBannedSenders();
loadFilterStatus();
