export const FILTER_CHAR_LIMIT = 1500;
export const MAX_OVERFLOW_FILTERS = 10;
export const UNSUBSCRIBE_LABEL_NAME = 'Unsubscribe';

/**
 * Parse "Display Name <email@example.com>" into "email@example.com".
 */
export function extractAddress(fromHeader) {
  if (!fromHeader) return '';
  const match = fromHeader.match(/<([^>]+)>/);
  return (match ? match[1] : fromHeader).toLowerCase().trim();
}

/**
 * Build Gmail filter criteria string from an array of addresses.
 * ["a@x.com", "b@y.com"] -> "{a@x.com b@y.com}"
 */
export function buildCriteriaString(addresses) {
  if (!addresses || addresses.length === 0) return '';
  if (addresses.length === 1) return addresses[0];
  return `{${addresses.join(' ')}}`;
}

/**
 * Parse a criteria string back into individual addresses.
 * "{a@x.com b@y.com}" -> ["a@x.com", "b@y.com"]
 */
export function parseCriteriaAddresses(criteria) {
  if (!criteria) return [];
  const inner = criteria.replace(/^\{/, '').replace(/\}$/, '').trim();
  if (!inner) return [];
  return inner.split(/\s+/).filter(Boolean);
}

/**
 * Add an address to an existing criteria string, returning the new criteria.
 */
export function addAddressToCriteria(criteria, address) {
  const addresses = parseCriteriaAddresses(criteria);
  const addr = address.toLowerCase().trim();
  if (!addresses.includes(addr)) {
    addresses.push(addr);
  }
  return buildCriteriaString(addresses);
}

/**
 * Remove an address from a criteria string, returning the new criteria.
 */
export function removeAddressFromCriteria(criteria, address) {
  const addresses = parseCriteriaAddresses(criteria);
  const addr = address.toLowerCase().trim();
  const filtered = addresses.filter((a) => a !== addr);
  return buildCriteriaString(filtered);
}

/**
 * Check if an address exists in a criteria string.
 */
export function criteriaContainsAddress(criteria, address) {
  const addresses = parseCriteriaAddresses(criteria);
  return addresses.includes(address.toLowerCase().trim());
}
