import { executeBan, executeUnban, executeBulkUnban, getBannedSenderList, processCleanupQueue } from './ban-engine.js';
import { getFilterStatus } from './filter-manager.js';
import { ensureAuth } from './gmail-api.js';
import { getProgress, clearQueue } from './cleanup-queue.js';

let cleanupRunning = false;

async function startCleanup() {
  if (cleanupRunning) return;
  cleanupRunning = true;
  try {
    await processCleanupQueue();
  } finally {
    cleanupRunning = false;
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const { type, payload } = message;

  console.log('[Shadow Ban] Message received:', type, payload);

  const handlers = {
    ENSURE_AUTH: () => ensureAuth(),
    BAN_SENDERS: async () => {
      const result = await executeBan(payload.addresses);
      // Start cleanup async — don't block the response.
      // Content script polling keeps the worker alive and resumes if needed.
      startCleanup();
      return result;
    },
    UNBAN_SENDER: () => executeUnban(payload.address),
    BULK_UNBAN: () => executeBulkUnban(payload.addresses),
    GET_BANNED_LIST: () => getBannedSenderList(),
    GET_FILTER_STATUS: () => getFilterStatus(),
    CLEAR_CLEANUP: async () => {
      await clearQueue();
      return { success: true };
    },
    GET_CLEANUP_PROGRESS: async () => {
      const progress = await getProgress();
      // Resume cleanup if the queue has pending work but nothing is running.
      // This handles the case where the service worker died mid-cleanup
      // and the content script's poll wakes it back up.
      if (progress && !progress.done && !cleanupRunning) {
        startCleanup();
      }
      return progress;
    },
  };

  const handler = handlers[type];
  if (!handler) {
    sendResponse({ error: `Unknown message type: ${type}` });
    return false;
  }

  handler()
    .then((result) => {
      console.log('[Shadow Ban] Success:', type, result);
      sendResponse(result);
    })
    .catch((error) => {
      console.error('[Shadow Ban] Error:', type, error.message, error.stack);
      sendResponse({ error: error.message });
    });

  return true;
});
