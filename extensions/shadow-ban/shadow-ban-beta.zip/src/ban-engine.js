import * as storage from './storage.js';
import * as gmailApi from './gmail-api.js';
import { ensureUnsubscribeLabel } from './label-manager.js';
import {
  addSenderToFilter,
  removeSenderFromFilter,
  rebuildAllFilters,
} from './filter-manager.js';
import { UNSUBSCRIBE_LABEL_NAME } from './address-utils.js';
import * as cleanupQueue from './cleanup-queue.js';

export async function executeBan(addresses) {
  console.log('[Shadow Ban] executeBan called with', addresses);

  // Deduplicate and normalize
  const unique = [...new Set(addresses.map((a) => a.toLowerCase().trim()))];

  // Filter out already-banned
  const currentBanned = await storage.getBannedSenders();
  const newAddresses = unique.filter((a) => !currentBanned.includes(a));
  console.log('[Shadow Ban] New addresses to ban:', newAddresses);

  if (newAddresses.length === 0) {
    return { success: true, count: 0, message: 'All senders already banned' };
  }

  // Ensure label exists
  console.log('[Shadow Ban] Ensuring label exists...');
  const labelId = await ensureUnsubscribeLabel();
  console.log('[Shadow Ban] Label ID:', labelId);

  // Add each to filters (or rebuild if bulk)
  if (newAddresses.length === 1) {
    console.log('[Shadow Ban] Adding single sender to filter...');
    const result = await addSenderToFilter(newAddresses[0], labelId);
    console.log('[Shadow Ban] Filter result:', result);
    if (!result.success) return result;
  } else {
    console.log('[Shadow Ban] Rebuilding filters for bulk ban...');
    const allBanned = [...currentBanned, ...newAddresses];
    await rebuildAllFilters(allBanned, labelId);
  }

  // Add to banned senders list
  for (const addr of newAddresses) {
    await storage.addBannedSender(addr);
  }
  console.log('[Shadow Ban] Saved banned senders to storage');

  // Enqueue message cleanup (processed async by processCleanupQueue)
  await cleanupQueue.enqueueCleanup(newAddresses, labelId);
  console.log('[Shadow Ban] Enqueued', newAddresses.length, 'senders for cleanup');

  return { success: true, count: newAddresses.length };
}

export async function processCleanupQueue(onProgress) {
  let next;
  while ((next = await cleanupQueue.nextSender())) {
    const { address, queue } = next;
    console.log('[Shadow Ban] Cleaning up messages for', address);

    const messageCount = await moveExistingMessages(address, queue.labelId);

    const updated = await cleanupQueue.markSenderDone(messageCount);
    if (onProgress && updated) {
      onProgress({
        completed: updated.completed,
        total: updated.total,
        totalMessages: updated.totalMessages,
        done: updated.pending.length === 0,
      });
    }
  }

  // Don't clear the queue here — leave the completed state for the
  // content script's poll to pick up and show the completion banner.
  // The queue is cleared when the user dismisses the banner or on
  // the next page load.
}

export async function executeBulkUnban(addresses) {
  const toRemove = new Set(addresses.map((a) => a.toLowerCase().trim()));
  const currentBanned = await storage.getBannedSenders();
  const remaining = currentBanned.filter((a) => !toRemove.has(a));

  const labelId = await ensureUnsubscribeLabel();

  // Rebuild filters with remaining senders (much faster than one-by-one)
  await rebuildAllFilters(remaining, labelId);
  await storage.setBannedSenders(remaining);

  // Restore messages for each unbanned sender
  let totalRestored = 0;
  for (const addr of toRemove) {
    totalRestored += await restoreMessages(addr, labelId);
  }

  return { success: true, unbannedCount: toRemove.size, restoredCount: totalRestored };
}

export async function executeUnban(address) {
  const addr = address.toLowerCase().trim();
  const isBanned = await storage.isSenderBanned(addr);
  if (!isBanned) {
    return { success: false, error: 'Sender is not banned' };
  }

  const labelId = await ensureUnsubscribeLabel();

  await removeSenderFromFilter(addr, labelId);
  await storage.removeBannedSender(addr);

  const restoredCount = await restoreMessages(addr, labelId);

  return { success: true, restoredCount };
}

export async function getBannedSenderList() {
  const senders = await storage.getBannedSenders();
  return { success: true, senders };
}

async function moveExistingMessages(sender, labelId) {
  const messages = await gmailApi.listMessages(`from:${sender} in:inbox`);
  if (messages.length === 0) return 0;

  const ids = messages.map((m) => m.id);
  await gmailApi.batchModifyMessages(ids, [labelId], ['INBOX']);
  return ids.length;
}

async function restoreMessages(sender, labelId) {
  const messages = await gmailApi.listMessages(
    `from:${sender} label:${UNSUBSCRIBE_LABEL_NAME}`,
  );
  if (messages.length === 0) return 0;

  const ids = messages.map((m) => m.id);
  await gmailApi.batchModifyMessages(ids, ['INBOX'], [labelId]);
  return ids.length;
}
