const QUEUE_KEY = 'sb_cleanup_queue';

async function getQueue() {
  const result = await chrome.storage.local.get(QUEUE_KEY);
  return result[QUEUE_KEY] || null;
}

async function setQueue(queue) {
  await chrome.storage.local.set({ [QUEUE_KEY]: queue });
}

export async function enqueueCleanup(senders, labelId, mode = 'ban') {
  const existing = await getQueue();

  if (existing && existing.pending.length > 0) {
    const newPending = senders.filter((s) => !existing.pending.includes(s));
    existing.pending.push(...newPending);
    existing.total = existing.completed + existing.pending.length;
    await setQueue(existing);
    return existing;
  }

  const queue = {
    pending: [...senders],
    total: senders.length,
    completed: 0,
    totalMessages: 0,
    labelId,
    mode,
  };
  await setQueue(queue);
  return queue;
}

export async function nextSender() {
  const queue = await getQueue();
  if (!queue || queue.pending.length === 0) return null;
  return { address: queue.pending[0], queue };
}

export async function markSenderDone(messageCount = 0) {
  const queue = await getQueue();
  if (!queue || queue.pending.length === 0) return null;

  queue.pending.shift();
  queue.completed += 1;
  queue.totalMessages += messageCount;

  await setQueue(queue);
  return queue;
}

export async function getProgress() {
  const queue = await getQueue();
  if (!queue) return null;
  return {
    completed: queue.completed,
    total: queue.total,
    totalMessages: queue.totalMessages,
    done: queue.pending.length === 0,
    mode: queue.mode,
  };
}

export async function clearQueue() {
  await chrome.storage.local.remove(QUEUE_KEY);
}

export { QUEUE_KEY, getQueue };
