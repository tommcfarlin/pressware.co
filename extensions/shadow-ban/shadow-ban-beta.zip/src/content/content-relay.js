// ISOLATED world content script for mail.google.com
// Directly observes Gmail DOM and injects a toolbar ban button.
// No MAIN world injection needed — ISOLATED world can manipulate the DOM.

const TOOLBAR_SELECTOR = 'div[gh="mtb"]';
const BUTTON_ID = 'sb-ban-btn';
const TOAST_ID = 'sb-toast';
const BANNER_ID = 'sb-cleanup-banner';
const TOAST_DURATION = 3500;
const POLL_INTERVAL = 3000;

// Declared early so injectBanButton can pause/resume it
let observer = null;
let debounceTimer = null;
let progressPollTimer = null;

function createBanButton() {
  const btn = document.createElement('div');
  btn.id = BUTTON_ID;
  btn.setAttribute('role', 'button');
  btn.setAttribute('tabindex', '0');
  btn.setAttribute('data-tooltip', 'Shadow Ban');
  btn.setAttribute('aria-label', 'Shadow Ban selected senders');

  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', '20');
  svg.setAttribute('height', '20');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', '#444');
  svg.setAttribute('stroke-width', '2');
  svg.setAttribute('stroke-linecap', 'round');

  const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  circle.setAttribute('cx', '12');
  circle.setAttribute('cy', '12');
  circle.setAttribute('r', '9');
  svg.appendChild(circle);

  const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  line.setAttribute('x1', '5.5');
  line.setAttribute('y1', '5.5');
  line.setAttribute('x2', '18.5');
  line.setAttribute('y2', '18.5');
  svg.appendChild(line);

  svg.style.display = 'block';
  btn.appendChild(svg);
  btn.style.cssText = [
    'display: inline-flex',
    'align-items: center',
    'justify-content: center',
    'align-self: center',
    'min-width: 40px',
    'height: 40px',
    'padding: 0 8px',
    'border-radius: 50%',
    'cursor: pointer',
    'font-family: "Google Sans", Roboto, sans-serif',
    'font-size: 12px',
    'font-weight: 500',
    'color: #444',
    'background: transparent',
    'user-select: none',
    'box-sizing: border-box',
  ].join(';');

  btn.addEventListener('mouseenter', () => {
    btn.style.background = 'rgba(0,0,0,0.06)';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.background = 'transparent';
  });

  btn.addEventListener('click', handleBanClick);
  return btn;
}

function findButtonRow() {
  const toolbar = document.querySelector(TOOLBAR_SELECTOR);
  if (!toolbar) return null;

  // The action buttons (archive, delete, etc.) are div[act] elements.
  // Find the container that holds them — that's where we insert.
  const actionBtn = toolbar.querySelector('div[act]');
  if (actionBtn) return actionBtn.parentElement;

  // Fallback: first child div of the toolbar
  return toolbar.querySelector('div') || toolbar;
}

function startObserver() {
  observer.observe(document.body, { childList: true, subtree: true });
}

function injectBanButton() {
  if (document.getElementById(BUTTON_ID)) return;
  const row = findButtonRow();
  if (!row) return;

  // Pause observer while we modify the DOM to avoid re-triggering
  observer.disconnect();
  row.appendChild(createBanButton());
  startObserver();
}

function getSelectedSenderAddresses() {
  const senders = new Set();

  // Gmail marks selected rows with aria-checked checkboxes
  const checkboxes = document.querySelectorAll(
    'div[role="checkbox"][aria-checked="true"]',
  );

  for (const checkbox of checkboxes) {
    // Walk up to the table row
    const row = checkbox.closest('tr');
    if (!row) continue;

    // Gmail puts sender email in span[email] attributes within the row
    const emailSpans = row.querySelectorAll('span[email]');
    for (const span of emailSpans) {
      const email = span.getAttribute('email');
      if (email) {
        senders.add(email.toLowerCase().trim());
      }
    }
  }

  return [...senders];
}

// Send a message to the service worker, handling stale context.
// When the service worker dies, chrome.runtime can become undefined.
// A page reload is the only reliable fix for a dead content script context.
async function sendMessage(msg) {
  if (!chrome.runtime?.sendMessage) {
    throw new Error('CONTEXT_INVALIDATED');
  }
  return chrome.runtime.sendMessage(msg);
}

// --- Toast (used for errors only) ---

function showToast(message) {
  const existing = document.getElementById(TOAST_ID);
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = TOAST_ID;
  toast.textContent = message;
  toast.style.cssText = [
    'position: fixed',
    'bottom: 20px',
    'left: 20px',
    'background: #323232',
    'color: #fff',
    'font-family: "Google Sans", Roboto, sans-serif',
    'font-size: 14px',
    'padding: 12px 24px',
    'border-radius: 4px',
    'box-shadow: 0 2px 8px rgba(0,0,0,0.3)',
    'z-index: 999999',
    'opacity: 0',
    'transform: translateY(20px)',
    'transition: opacity 0.3s ease, transform 0.3s ease',
  ].join(';');

  document.body.appendChild(toast);

  // Trigger slide-up animation
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
  });

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(20px)';
    setTimeout(() => toast.remove(), 300);
  }, TOAST_DURATION);
}

// --- Persistent cleanup banner ---

function ensureBanner() {
  let banner = document.getElementById(BANNER_ID);
  if (banner) return banner;

  banner = document.createElement('div');
  banner.id = BANNER_ID;
  banner.style.cssText = [
    'position: fixed',
    'bottom: 0',
    'left: 0',
    'right: 0',
    'background: #323232',
    'color: #fff',
    'font-family: "Google Sans", Roboto, sans-serif',
    'font-size: 14px',
    'padding: 16px 24px',
    'box-shadow: 0 -2px 8px rgba(0,0,0,0.3)',
    'z-index: 999999',
    'display: flex',
    'flex-direction: column',
    'gap: 8px',
    'transform: translateY(100%)',
    'transition: transform 0.3s ease',
  ].join(';');

  document.body.appendChild(banner);
  requestAnimationFrame(() => {
    banner.style.transform = 'translateY(0)';
  });

  return banner;
}

function dismissBanner() {
  const banner = document.getElementById(BANNER_ID);
  if (!banner) return;
  banner.style.transform = 'translateY(100%)';
  setTimeout(() => banner.remove(), 300);
  stopProgressPoll();
  // Clear the completed queue from storage
  sendMessage({ type: 'CLEAR_CLEANUP' }).catch(() => {});
}

function showBannerConfirmed(count) {
  const banner = ensureBanner();
  while (banner.firstChild) banner.removeChild(banner.firstChild);

  const senderWord = count === 1 ? 'this sender' : `these ${count} senders`;

  const message = document.createElement('div');
  message.textContent = `Got it \u2014 you\u2019ll never see emails from ${senderWord} in your inbox again.`;
  message.style.fontWeight = '500';
  banner.appendChild(message);

  const sub = document.createElement('div');
  sub.textContent = 'Now tidying up old emails\u2026';
  sub.style.cssText = 'opacity: 0.7; font-size: 13px;';
  banner.appendChild(sub);
}

function showBannerProgress(progress) {
  const banner = ensureBanner();
  while (banner.firstChild) banner.removeChild(banner.firstChild);

  const fraction = progress.total > 0 ? progress.completed / progress.total : 0;

  const message = document.createElement('div');
  message.textContent = `Tidying up old emails\u2026 ${progress.completed} of ${progress.total} senders`;
  message.style.fontWeight = '500';
  banner.appendChild(message);

  // Progress bar
  const barContainer = document.createElement('div');
  barContainer.style.cssText = [
    'width: 100%',
    'height: 4px',
    'background: rgba(255,255,255,0.2)',
    'border-radius: 2px',
    'overflow: hidden',
  ].join(';');

  const barFill = document.createElement('div');
  barFill.style.cssText = [
    `width: ${Math.round(fraction * 100)}%`,
    'height: 100%',
    'background: #8ab4f8',
    'border-radius: 2px',
    'transition: width 0.3s ease',
  ].join(';');

  barContainer.appendChild(barFill);
  banner.appendChild(barContainer);

  const sub = document.createElement('div');
  sub.textContent = 'You can close Gmail or leave \u2014 we\u2019ll finish whenever you\u2019re back.';
  sub.style.cssText = 'opacity: 0.7; font-size: 13px;';
  banner.appendChild(sub);
}

function showBannerComplete(totalMessages) {
  const banner = ensureBanner();
  while (banner.firstChild) banner.removeChild(banner.firstChild);

  // Top row: message + dismiss button
  const row = document.createElement('div');
  row.style.cssText = 'display: flex; justify-content: space-between; align-items: flex-start;';

  const textCol = document.createElement('div');

  const message = document.createElement('div');
  const emailWord = totalMessages === 1 ? 'email' : 'emails';
  message.textContent = totalMessages > 0
    ? `All done! ${totalMessages.toLocaleString()} ${emailWord} moved to your Unsubscribe folder.`
    : 'All done! No old emails needed to be moved.';
  message.style.fontWeight = '500';
  textCol.appendChild(message);

  const sub = document.createElement('div');
  sub.textContent = 'Nothing was deleted \u2014 you can find them anytime under the Unsubscribe label.';
  sub.style.cssText = 'opacity: 0.7; font-size: 13px; margin-top: 4px;';
  textCol.appendChild(sub);

  row.appendChild(textCol);

  const dismissBtn = document.createElement('button');
  dismissBtn.textContent = '\u2715';
  dismissBtn.style.cssText = [
    'background: none',
    'border: none',
    'color: #fff',
    'font-size: 18px',
    'cursor: pointer',
    'padding: 0 0 0 16px',
    'opacity: 0.7',
    'flex-shrink: 0',
  ].join(';');
  dismissBtn.addEventListener('mouseenter', () => { dismissBtn.style.opacity = '1'; });
  dismissBtn.addEventListener('mouseleave', () => { dismissBtn.style.opacity = '0.7'; });
  dismissBtn.addEventListener('click', dismissBanner);
  row.appendChild(dismissBtn);

  banner.appendChild(row);
}

function updateBannerFromProgress(progress) {
  if (!progress) return;

  if (progress.done) {
    showBannerComplete(progress.totalMessages);
    stopProgressPoll();
  } else if (progress.completed > 0) {
    showBannerProgress(progress);
  }
  // If completed === 0, keep showing the "confirmed" phase
}

// --- Progress polling ---

async function pollOnce() {
  try {
    const progress = await sendMessage({ type: 'GET_CLEANUP_PROGRESS' });
    updateBannerFromProgress(progress);
  } catch (_e) {
    stopProgressPoll();
  }
}

function startProgressPoll() {
  if (progressPollTimer) return;
  // Poll immediately so we don't miss fast completions, then repeat
  pollOnce();
  progressPollTimer = setInterval(pollOnce, POLL_INTERVAL);
}

function stopProgressPoll() {
  if (progressPollTimer) {
    clearInterval(progressPollTimer);
    progressPollTimer = null;
  }
}

async function checkForActiveCleanup() {
  try {
    const progress = await sendMessage({ type: 'GET_CLEANUP_PROGRESS' });
    if (progress && !progress.done) {
      showBannerProgress(progress);
      startProgressPoll();
    } else if (progress && progress.done) {
      // Stale completed queue from a previous session — clear it
      sendMessage({ type: 'CLEAR_CLEANUP' }).catch(() => {});
    }
  } catch (_e) {
    // Extension context not ready — ignore
  }
}

// --- Row removal animation ---

function removeSelectedRows() {
  const checkboxes = document.querySelectorAll(
    'div[role="checkbox"][aria-checked="true"]',
  );

  const rows = [];
  for (const checkbox of checkboxes) {
    const row = checkbox.closest('tr');
    if (row) rows.push(row);
  }

  if (rows.length === 0) return;

  observer.disconnect();

  for (const row of rows) {
    row.style.transition = 'opacity 0.4s ease';
    row.style.opacity = '0';
  }

  setTimeout(() => {
    for (const row of rows) {
      row.remove();
    }
    startObserver();
  }, 400);
}

// --- Ban click handler ---

async function handleBanClick() {
  const addresses = getSelectedSenderAddresses();
  console.log('[Shadow Ban] Selected addresses:', addresses);
  if (addresses.length === 0) {
    console.log('[Shadow Ban] No addresses found in selection');
    return;
  }

  const btn = document.getElementById(BUTTON_ID);
  if (btn) {
    btn.style.opacity = '0.4';
    btn.style.pointerEvents = 'none';
  }

  try {
    // Step 1: Ensure authenticated first (this may open a popup).
    // We do this separately so the token is cached before the ban flow,
    // avoiding service worker termination during the interactive auth.
    console.log('[Shadow Ban] Ensuring auth...');
    const authResult = await sendMessage({ type: 'ENSURE_AUTH' });
    console.log('[Shadow Ban] Auth result:', authResult);

    if (authResult?.error) {
      throw new Error(authResult.error);
    }

    // Step 2: Now ban with token already cached (no interactive popup needed)
    console.log('[Shadow Ban] Sending BAN_SENDERS...');
    const result = await sendMessage({
      type: 'BAN_SENDERS',
      payload: { addresses },
    });
    console.log('[Shadow Ban] Ban result:', result);

    if (btn) btn.style.opacity = '1';
    setTimeout(() => {
      if (btn) btn.style.pointerEvents = '';
    }, 2000);

    if (result?.error) {
      throw new Error(result.error);
    }

    const count = result?.count || addresses.length;
    showBannerConfirmed(count);
    removeSelectedRows();
    startProgressPoll();
  } catch (error) {
    if (btn) {
      btn.style.opacity = '1';
      btn.style.pointerEvents = '';
    }
    if (error.message === 'CONTEXT_INVALIDATED') {
      console.warn('[Shadow Ban] Extension context lost — reloading page');
      window.location.reload();
      return;
    }
    console.error('[Shadow Ban] Error:', error);
    showToast('Failed to ban sender. Please try again.');
  }
}

// Debounced injection — Gmail triggers many rapid DOM mutations.
// Without debouncing, the observer can cause a runaway loop (RESULT_CODE_HUNG).
function scheduleInject() {
  if (debounceTimer) return;
  debounceTimer = setTimeout(() => {
    debounceTimer = null;
    injectBanButton();
  }, 300);
}

// Initialize observer and start watching
observer = new MutationObserver(scheduleInject);
startObserver();

// Also try immediately in case the toolbar is already there
injectBanButton();

// Check for in-progress cleanup (e.g., worker died and restarted)
checkForActiveCleanup();

// Listen for refresh requests from the popup
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'REFRESH_INBOX') {
    if (location.hash === '#inbox') {
      location.reload();
    } else {
      location.hash = '#inbox';
    }
    sendResponse({ success: true });
  }
});
