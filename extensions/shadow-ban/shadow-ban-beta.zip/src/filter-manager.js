import * as gmailApi from './gmail-api.js';
import * as storage from './storage.js';
import {
  FILTER_CHAR_LIMIT,
  MAX_OVERFLOW_FILTERS,
  buildCriteriaString,
  parseCriteriaAddresses,
  addAddressToCriteria,
  removeAddressFromCriteria,
} from './address-utils.js';

export async function addSenderToFilter(address, labelId) {
  const metadata = await storage.getFilterMetadata();
  const criteria = await storage.getFilterCriteria();

  // Find a filter with room
  let targetIndex = -1;
  for (let i = 0; i < criteria.length; i++) {
    const newCriteria = addAddressToCriteria(criteria[i], address);
    if (newCriteria.length <= FILTER_CHAR_LIMIT) {
      targetIndex = i;
      break;
    }
  }

  // Create overflow filter if none have room
  if (targetIndex === -1) {
    if (criteria.length >= MAX_OVERFLOW_FILTERS) {
      return { success: false, error: 'Maximum filter limit reached' };
    }
    targetIndex = criteria.length;
    criteria.push('');
    metadata.push({ id: null, charCount: 0 });
  }

  // Delete old filter if it exists
  if (metadata[targetIndex]?.id) {
    await gmailApi.deleteFilter(metadata[targetIndex].id);
  }

  // Build new criteria and create filter
  const newCriteria = addAddressToCriteria(criteria[targetIndex], address);
  const filter = await gmailApi.createFilter(newCriteria, labelId);

  // Update storage
  criteria[targetIndex] = newCriteria;
  metadata[targetIndex] = { id: filter.id, charCount: newCriteria.length };
  await storage.setFilterCriteria(criteria);
  await storage.setFilterMetadata(metadata);

  return { success: true, filterIndex: targetIndex };
}

export async function removeSenderFromFilter(address, labelId) {
  const metadata = await storage.getFilterMetadata();
  const criteria = await storage.getFilterCriteria();

  // Find which filter contains this address
  let targetIndex = -1;
  for (let i = 0; i < criteria.length; i++) {
    const addresses = parseCriteriaAddresses(criteria[i]);
    if (addresses.includes(address.toLowerCase().trim())) {
      targetIndex = i;
      break;
    }
  }

  if (targetIndex === -1) {
    return { success: false, error: 'Address not found in any filter' };
  }

  // Delete old filter
  if (metadata[targetIndex]?.id) {
    await gmailApi.deleteFilter(metadata[targetIndex].id);
  }

  // Build new criteria
  const newCriteria = removeAddressFromCriteria(criteria[targetIndex], address);

  if (!newCriteria || newCriteria === '{}') {
    // Filter is now empty — remove it
    criteria.splice(targetIndex, 1);
    metadata.splice(targetIndex, 1);
  } else {
    // Recreate filter with updated criteria
    const filter = await gmailApi.createFilter(newCriteria, labelId);
    criteria[targetIndex] = newCriteria;
    metadata[targetIndex] = { id: filter.id, charCount: newCriteria.length };
  }

  await storage.setFilterCriteria(criteria);
  await storage.setFilterMetadata(metadata);

  return { success: true };
}

export async function rebuildAllFilters(senders, labelId) {
  const metadata = await storage.getFilterMetadata();

  // Delete all existing filters
  for (const meta of metadata) {
    if (meta?.id) {
      try {
        await gmailApi.deleteFilter(meta.id);
      } catch (_e) {
        /* already deleted */
      }
    }
  }

  if (senders.length === 0) {
    await storage.setFilterCriteria([]);
    await storage.setFilterMetadata([]);
    return { success: true, filterCount: 0 };
  }

  // Pack senders into filters respecting char limit
  const newCriteria = [];
  const newMetadata = [];
  let currentAddresses = [];

  for (const sender of senders) {
    const testCriteria = buildCriteriaString([...currentAddresses, sender]);
    if (testCriteria.length > FILTER_CHAR_LIMIT && currentAddresses.length > 0) {
      const criteriaStr = buildCriteriaString(currentAddresses);
      const filter = await gmailApi.createFilter(criteriaStr, labelId);
      newCriteria.push(criteriaStr);
      newMetadata.push({ id: filter.id, charCount: criteriaStr.length });
      currentAddresses = [];
    }
    currentAddresses.push(sender);
  }

  // Final batch
  if (currentAddresses.length > 0) {
    const criteriaStr = buildCriteriaString(currentAddresses);
    const filter = await gmailApi.createFilter(criteriaStr, labelId);
    newCriteria.push(criteriaStr);
    newMetadata.push({ id: filter.id, charCount: criteriaStr.length });
  }

  await storage.setFilterCriteria(newCriteria);
  await storage.setFilterMetadata(newMetadata);

  return { success: true, filterCount: newCriteria.length };
}

export async function getFilterStatus() {
  const metadata = await storage.getFilterMetadata();
  const criteria = await storage.getFilterCriteria();
  return metadata.map((meta, i) => ({
    index: i,
    charCount: meta.charCount,
    charLimit: FILTER_CHAR_LIMIT,
    addressCount: parseCriteriaAddresses(criteria[i] || '').length,
  }));
}
