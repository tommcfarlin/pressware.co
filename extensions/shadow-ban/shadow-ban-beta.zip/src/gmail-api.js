const GMAIL_BASE = 'https://www.googleapis.com/gmail/v1/users/me';
const TOKEN_EXPIRY_BUFFER = 60; // seconds before expiry to consider token stale

let cachedToken = null;
let tokenTimer = null;

/**
 * Token lifecycle:
 * 1. In-memory cache (fastest, lost when service worker dies ~30s MV3)
 * 2. chrome.storage.session (survives worker restarts, clears on browser close)
 * 3. Silent re-auth via launchWebAuthFlow({ interactive: false }) — works if
 *    user already granted consent, avoids popup
 * 4. Interactive auth via launchWebAuthFlow({ interactive: true }) — last resort
 *
 * Google OAuth implicit flow tokens are fixed at 1 hour. With session persistence
 * and silent re-auth, users rarely see the OAuth popup after initial consent.
 */

async function getStoredToken() {
  const { sbToken, sbTokenExpiry } = await chrome.storage.session.get([
    'sbToken',
    'sbTokenExpiry',
  ]);
  if (!sbToken || !sbTokenExpiry) return null;
  const remaining = sbTokenExpiry - Date.now();
  if (remaining < TOKEN_EXPIRY_BUFFER * 1000) {
    chrome.storage.session.remove(['sbToken', 'sbTokenExpiry']);
    return null;
  }
  return sbToken;
}

async function setStoredToken(token, expiresIn) {
  await chrome.storage.session.set({
    sbToken: token,
    sbTokenExpiry: Date.now() + expiresIn * 1000,
  });
}

function clearStoredToken() {
  chrome.storage.session.remove(['sbToken', 'sbTokenExpiry']);
}

function buildAuthUrl() {
  const manifest = chrome.runtime.getManifest();
  const clientId = manifest.oauth2.client_id;
  const scopes = manifest.oauth2.scopes.join(' ');
  const redirectUrl = chrome.identity.getRedirectURL().replace(/\/$/, '');

  const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  authUrl.searchParams.set('client_id', clientId);
  authUrl.searchParams.set('redirect_uri', redirectUrl);
  authUrl.searchParams.set('response_type', 'token');
  authUrl.searchParams.set('scope', scopes);

  return authUrl.toString();
}

function parseTokenFromUrl(responseUrl) {
  const hash = new URL(responseUrl).hash.substring(1);
  const params = new URLSearchParams(hash);
  const token = params.get('access_token');
  const expiresIn = parseInt(params.get('expires_in') || '3600', 10);
  return { token, expiresIn };
}

async function getToken() {
  console.log('[Shadow Ban] getToken called, cached:', !!cachedToken);

  // 1. In-memory cache
  if (cachedToken) return cachedToken;

  // 2. Session storage (survives service worker restarts)
  const storedToken = await getStoredToken();
  if (storedToken) {
    console.log('[Shadow Ban] Token restored from session storage');
    cachedToken = storedToken;
    return cachedToken;
  }

  // 3. Try silent re-auth (no popup if user already consented)
  const authUrlStr = buildAuthUrl();
  let responseUrl;
  try {
    console.log('[Shadow Ban] Trying silent re-auth...');
    responseUrl = await chrome.identity.launchWebAuthFlow({
      url: authUrlStr,
      interactive: false,
    });
  } catch (_silentErr) {
    // Silent auth failed — fall through to interactive
    console.log('[Shadow Ban] Silent auth failed, launching interactive flow');
  }

  // 4. Interactive auth (last resort)
  if (!responseUrl) {
    responseUrl = await chrome.identity.launchWebAuthFlow({
      url: authUrlStr,
      interactive: true,
    });
  }

  console.log('[Shadow Ban] Auth flow returned');

  const { token, expiresIn } = parseTokenFromUrl(responseUrl);

  if (!token) {
    throw new Error('No access token received');
  }

  cachedToken = token;

  // Persist to session storage
  await setStoredToken(token, expiresIn);

  // Clear in-memory cache when token expires
  if (tokenTimer) clearTimeout(tokenTimer);
  tokenTimer = setTimeout(() => {
    cachedToken = null;
    tokenTimer = null;
  }, (expiresIn - TOKEN_EXPIRY_BUFFER) * 1000);

  console.log('[Shadow Ban] Token acquired, expires in', expiresIn, 's');
  return token;
}

// Trigger auth flow proactively (before any API call)
export async function ensureAuth() {
  await getToken();
  return { success: true };
}

// Force a fresh token on next request (e.g. after 401)
export function clearTokenCache() {
  cachedToken = null;
  if (tokenTimer) {
    clearTimeout(tokenTimer);
    tokenTimer = null;
  }
  clearStoredToken();
}

async function gmailFetch(path, options = {}) {
  console.log('[Shadow Ban] gmailFetch:', options.method || 'GET', path);
  const token = await getToken();
  const response = await fetch(`${GMAIL_BASE}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  if (response.status === 401) {
    clearTokenCache();
    throw new Error('Token expired — retry will re-authenticate');
  }
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.error?.message || `Gmail API error: ${response.status}`);
  }
  if (response.status === 204) return null;
  return response.json();
}

// --- Labels ---

export async function listLabels() {
  const data = await gmailFetch('/labels');
  return data.labels || [];
}

export async function getLabel(labelId) {
  return gmailFetch(`/labels/${encodeURIComponent(labelId)}`);
}

export async function createLabel(name) {
  return gmailFetch('/labels', {
    method: 'POST',
    body: JSON.stringify({
      name,
      labelListVisibility: 'labelShow',
      messageListVisibility: 'show',
    }),
  });
}

// --- Filters ---

export async function listFilters() {
  const data = await gmailFetch('/settings/filters');
  return data.filter || [];
}

export async function createFilter(fromCriteria, labelId) {
  return gmailFetch('/settings/filters', {
    method: 'POST',
    body: JSON.stringify({
      criteria: { from: fromCriteria },
      action: {
        addLabelIds: [labelId],
        removeLabelIds: ['INBOX'],
      },
    }),
  });
}

export async function deleteFilter(filterId) {
  return gmailFetch(`/settings/filters/${encodeURIComponent(filterId)}`, {
    method: 'DELETE',
  });
}

// --- Messages ---

const BATCH_MODIFY_LIMIT = 1000;

export async function listMessages(query) {
  const allMessages = [];
  let pageToken = null;

  do {
    const params = new URLSearchParams({ q: query, maxResults: '500' });
    if (pageToken) params.set('pageToken', pageToken);

    const data = await gmailFetch(`/messages?${params}`);
    if (data.messages) allMessages.push(...data.messages);
    pageToken = data.nextPageToken || null;
  } while (pageToken);

  return allMessages;
}

export async function batchModifyMessages(messageIds, addLabelIds, removeLabelIds) {
  if (messageIds.length === 0) return;

  for (let i = 0; i < messageIds.length; i += BATCH_MODIFY_LIMIT) {
    const chunk = messageIds.slice(i, i + BATCH_MODIFY_LIMIT);
    await gmailFetch('/messages/batchModify', {
      method: 'POST',
      body: JSON.stringify({ ids: chunk, addLabelIds, removeLabelIds }),
    });
  }
}
