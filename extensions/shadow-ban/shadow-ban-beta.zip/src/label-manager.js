import * as gmailApi from './gmail-api.js';
import * as storage from './storage.js';
import { UNSUBSCRIBE_LABEL_NAME } from './address-utils.js';

export async function ensureUnsubscribeLabel() {
  // 1. Check cache
  const cachedId = await storage.getCachedLabelId();
  if (cachedId) {
    const exists = await verifyLabelExists(cachedId);
    if (exists) return cachedId;
  }

  // 2. Search by name
  const found = await findLabelByName(UNSUBSCRIBE_LABEL_NAME);
  if (found) {
    await storage.setCachedLabelId(found);
    return found;
  }

  // 3. Create
  const label = await gmailApi.createLabel(UNSUBSCRIBE_LABEL_NAME);
  await storage.setCachedLabelId(label.id);
  return label.id;
}

async function verifyLabelExists(labelId) {
  try {
    await gmailApi.getLabel(labelId);
    return true;
  } catch (_e) {
    return false;
  }
}

async function findLabelByName(name) {
  const labels = await gmailApi.listLabels();
  const match = labels.find((l) => l.name === name);
  return match ? match.id : null;
}
