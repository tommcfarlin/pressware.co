const KEYS = {
  LABEL_ID: 'sb_label_id',
  FILTER_IDS: 'sb_filter_ids',
  FILTER_CRITERIA: 'sb_filter_criteria',
  BANNED_SENDERS: 'sb_banned_senders',
};

async function get(key) {
  const result = await chrome.storage.sync.get(key);
  return result[key] ?? null;
}

async function set(key, value) {
  await chrome.storage.sync.set({ [key]: value });
}

async function remove(key) {
  await chrome.storage.sync.remove(key);
}

// --- Label ID ---

export async function getCachedLabelId() {
  return get(KEYS.LABEL_ID);
}

export async function setCachedLabelId(labelId) {
  await set(KEYS.LABEL_ID, labelId);
}

// --- Filter Metadata ---

export async function getFilterMetadata() {
  return (await get(KEYS.FILTER_IDS)) || [];
}

export async function setFilterMetadata(metadata) {
  await set(KEYS.FILTER_IDS, metadata);
}

// --- Filter Criteria ---

export async function getFilterCriteria() {
  return (await get(KEYS.FILTER_CRITERIA)) || [];
}

export async function setFilterCriteria(criteria) {
  await set(KEYS.FILTER_CRITERIA, criteria);
}

// --- Banned Senders ---

export async function getBannedSenders() {
  return (await get(KEYS.BANNED_SENDERS)) || [];
}

export async function setBannedSenders(senders) {
  await set(KEYS.BANNED_SENDERS, senders);
}

export async function addBannedSender(address) {
  const addr = address.toLowerCase().trim();
  const senders = await getBannedSenders();
  if (senders.includes(addr)) return false;
  senders.push(addr);
  await setBannedSenders(senders);
  return true;
}

export async function removeBannedSender(address) {
  const addr = address.toLowerCase().trim();
  const senders = await getBannedSenders();
  const index = senders.indexOf(addr);
  if (index === -1) return false;
  senders.splice(index, 1);
  await setBannedSenders(senders);
  return true;
}

export async function isSenderBanned(address) {
  const senders = await getBannedSenders();
  return senders.includes(address.toLowerCase().trim());
}

export { KEYS, remove };
